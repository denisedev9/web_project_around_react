import { useState } from "react";
export default function NewCard({ onAddPlaceSubmit }) {
 
 const [name, setName] = useState("");
const [link, setLink] = useState("");

function handleSubmit(e) {
  e.preventDefault();
    onAddPlaceSubmit(name, link);
    setName("");
    setLink("");
  }

  return (
    <form
      className="popup__form"
      name="card-form"
      id="new-card-form"
      noValidate
      onSubmit={handleSubmit}
    >
      <label className="popup__field">
        <input
          className="popup__input popup__input_type_card-name"
          id="card-name"
          maxLength="30"
          minLength="1"
          name="card-name"
          placeholder="Title"
          required
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <span className="popup__error" id="card-name-error"></span>
      </label>
      <label className="popup__field">
        <input
          className="popup__input popup__input_type_url"
          id="card-link"
          placeholder="Image link"
          type="url"
          name="link"
          value={link}
          onChange={(e) => setLink(e.target.value)}
          required
        />
        <span className="popup__error" id="card-link-error"></span>
      </label>

      <button className="button popup__button" type="submit">
        Guardar
      </button>
    </form>
  );
}